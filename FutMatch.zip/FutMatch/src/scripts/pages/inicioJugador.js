/**
 * INICIO JUGADOR - Scripts para la página de inicio del jugador
 * Funcionalidad: Inicialización y lógica de la página de inicio
 */

document.addEventListener("DOMContentLoaded", () => {
  // Aquí se puede agregar lógica adicional de la página
  // Por ejemplo: animaciones, eventos de tarjetas, etc.
});
