# Integrantes del equipo:

- Daniel Vidal, 35.065.354
- Martín Santo, 44.668.584
- Camila Santo, 42.076.819

# FutMatch:

Se trataría de una página para conectar jugadores y armar equipos en canchas cercanas al usuario para jugar fútbol casual. El usuario “jugador” puede ver en su mapa las canchas, y al clickear en una puede visualizar los distintos horarios en los que puede participar en un partido. También puede solicitar una reserva de cancha abierta, en la que los jugadores individuales o de grupos pequeños podrían solicitar participar en el equipo del que inicia la reserva o en el equipo rival. El usuario “administrador de cancha” puede gestionar los distintos horarios que ofrece y puede visualizar el historial de usuario de los jugadores que solicitan utilizar su predio. De esta manera, puede gestionar las solicitudes de su servicio de manera segura. 

Funcionalidades básicas relevantes:

- (jugador) Perfil con zona y posición para jugar,
- (jugador) Solicitar reserva de cancha en un lugar, fecha y hora determinados,
- (jugador) Sumarte a una reserva abierta en una cancha,
- (administrador) Gestionar perfil de la cancha,
- (administrador) Gestionar horarios ofrecidos,
- (administrador) Gestionar solicitudes de reservas,
- (administrador) Visualizar historial de conducta de jugadores.
